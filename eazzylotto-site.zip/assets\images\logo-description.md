# Logo EazzyLotto

## Description du Logo
- **EAZZY** : Texte blanc en gras
- **L** : Rouge vif
- **O** : Boule de loto jaune/dorée avec le numéro 9
- **T** : Vert vif  
- **T** : Rouge vif
- **O** : Boule de loto bleue avec le numéro 2

## Fond
- Noir profond avec bordure blanche
- Encadrement bleu en périphérie

## Utilisation
Ce logo sera intégré en CSS pour reproduire fidèlement l'apparence.